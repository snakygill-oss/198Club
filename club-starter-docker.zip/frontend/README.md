Frontend - Next.js starter

Docker:
Build: docker-compose build frontend
Run: docker-compose up frontend

Or run with npm locally:
1. cd frontend
2. npm install
3. copy .env.local.example to .env.local and adjust NEXT_PUBLIC_API
4. npm run dev
