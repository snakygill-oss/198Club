Backend - Node/Express starter

Docker:
Build: docker-compose build backend
Run: docker-compose up backend

Or run with npm locally:
1. cd backend
2. npm install
3. copy .env.example to .env and set values
4. npm run dev
